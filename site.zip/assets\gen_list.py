import json
import os
from pathlib import Path


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    images_dir = project_root / "assets" / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    exts = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}
    files = []
    for entry in images_dir.iterdir():
        if entry.is_file() and entry.suffix.lower() in exts:
            files.append(f"assets/images/{entry.name}")

    files.sort(key=lambda p: p.lower())

    out_path = images_dir / "list.json"
    out_path.write_text(json.dumps(files, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(f"已生成 {out_path.relative_to(project_root)}，共 {len(files)} 张")


if __name__ == "__main__":
    main()


