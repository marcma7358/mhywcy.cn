import base64
import json
import os
from pathlib import Path


MIME_BY_EXT = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".bmp": "image/bmp",
}

AUDIO_MIME_BY_EXT = {
    ".mp3": "audio/mpeg",
    ".m4a": "audio/mp4",
    ".aac": "audio/aac",
    ".wav": "audio/wav",
    ".ogg": "audio/ogg",
}


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8") if path.exists() else ""


def load_caption_map(images_dir: Path) -> dict[str, str]:
    caption_map: dict[str, str] = {}
    list_json = images_dir / "list.json"
    if list_json.exists():
        try:
            data = json.loads(list_json.read_text(encoding="utf-8"))
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict) and "src" in item:
                        name = Path(str(item["src"]).replace("\\", "/")).name
                        text = str(item.get("text", "")).strip()
                        if text:
                            caption_map[name] = text
        except Exception:
            pass
    return caption_map


def filename_to_caption(name: str) -> str:
    stem = Path(name).stem
    # 将下划线、连字符替换为空格，保留中文
    caption = stem.replace("_", " ").replace("-", " ")
    return caption


def build_album_items(images_dir: Path) -> list[dict]:
    caption_map = load_caption_map(images_dir)
    items: list[dict] = []
    for entry in sorted(images_dir.iterdir(), key=lambda p: p.name.lower()):
        if not entry.is_file():
            continue
        ext = entry.suffix.lower()
        if ext not in MIME_BY_EXT:
            continue
        mime = MIME_BY_EXT[ext]
        b64 = base64.b64encode(entry.read_bytes()).decode("ascii")
        data_uri = f"data:{mime};base64,{b64}"
        text = caption_map.get(entry.name) or filename_to_caption(entry.name)
        items.append({"src": data_uri, "text": text})
    return items


HTML_TEMPLATE = """<!DOCTYPE html>
<html lang=\"zh-CN\">
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\" />
  <title>马翰元 ❤️ 王彩雨 · 七周年电子相册</title>
  <meta name=\"theme-color\" content=\"#ff8fb1\" />
  <style>{css}</style>
</head>
<body>
  <div id=\"bg\"></div>
  <main class=\"container\"> 
    <header class=\"hero\">
      <h1>马翰元 ❤ 王彩雨</h1>
      <p class=\"subtitle\">七年之约 · 2018.8.19 — 2025.8.19</p>
      <div class=\"countup\">
        <span>我们已经相爱</span>
        <div id=\"timeCounters\">
          <span id=\"days\" class=\"num\"></span><span class=\"unit\">天</span>
          <span id=\"hours\" class=\"num\"></span><span class=\"unit\">小时</span>
          <span id=\"minutes\" class=\"num\"></span><span class=\"unit\">分钟</span>
          <span id=\"seconds\" class=\"num\"></span><span class=\"unit\">秒</span>
        </div>
      </div>
    </header>

    <section id=\"gallery\" class=\"section\">
      <h2>回忆相册（离线版）</h2>
      <div class=\"progress\" id=\"galleryProgressWrap\" aria-hidden=\"true\">
        <div class=\"progress-bar\" id=\"galleryProgress\"></div>
        <span class=\"progress-text\" id=\"galleryProgressText\"></span>
      </div>
      <div class=\"grid\" id=\"galleryGrid\"></div>
    </section>

    <section id=\"wishes\" class=\"section\">
      <h2>写给未来</h2>
      <p>愿与你看尽人间烟火，也愿每个清晨醒来，都能看到彼此的笑。</p>
    </section>

    <footer>
      <button id=\"playFireworks\" class=\"btn secondary\">撒点小心心</button>
      <p class=\"copy\">© 2018–2025 MHY & WCY · Love never ends</p>
    </footer>
  </main>

  <canvas id=\"heartCanvas\"></canvas>
  <!-- 电子相册 Lightbox -->
  <div id=\"lightbox\" aria-hidden=\"true\">
    <button class=\"lb-btn lb-close\" aria-label=\"关闭\">×</button>
    <button class=\"lb-btn lb-prev\" aria-label=\"上一张\">‹</button>
    <div class=\"lb-stage\">
      <img id=\"lb-img\" alt=\"相册预览\" />
      <div class=\"lb-caption\">
        <span id=\"lb-index\">1</span>/<span id=\"lb-total\">1</span>
        <span id=\"lb-text\"></span>
      </div>
    </div>
    <button class=\"lb-btn lb-next\" aria-label=\"下一张\">›</button>
    <button class=\"lb-btn lb-play\" aria-label=\"播放/暂停\">▶</button>
  </div>

  <audio id=\"bgm\" loop preload=\"auto\" src=\"{audio_src}\"></audio>
  <button id=\"musicToggle\" class=\"btn music-btn\" aria-label=\"音乐\">♪</button>

  <div id=\"cover\">\n    <div class=\"cover-content\">\n      <h1>马翰元 ❤ 王彩雨</h1>\n      <p>七周年纪念 · 2018.8.19 — 2025.8.19</p>\n      <button id=\"enterBtn\" class=\"btn\">进入相册</button>\n    </div>\n  </div>

  <script>window.ALBUM_ITEMS = {items_json};</script>
  <script>{js}</script>
</body>
</html>
"""


def make_inline_js() -> str:
    # 精简版脚本：计时、爱心动画、相册渲染(使用 window.ALBUM_ITEMS)
    return r"""
(function () {
  const START_DATE = new Date('2018-08-19T00:00:00+08:00');
  const daysEl = document.getElementById('days');
  const hoursEl = document.getElementById('hours');
  const minutesEl = document.getElementById('minutes');
  const secondsEl = document.getElementById('seconds');
  function pad(n){return String(n).padStart(2,'0');}
  function updateCounter(){
    const diffMs = Date.now() - START_DATE.getTime();
    const totalSeconds = Math.floor(diffMs/1000);
    const days = Math.floor(totalSeconds/86400);
    const hours = Math.floor((totalSeconds%86400)/3600);
    const minutes = Math.floor((totalSeconds%3600)/60);
    const seconds = totalSeconds%60;
    if (daysEl) daysEl.textContent = days;
    if (hoursEl) hoursEl.textContent = pad(hours);
    if (minutesEl) minutesEl.textContent = pad(minutes);
    if (secondsEl) secondsEl.textContent = pad(seconds);
  }
  updateCounter(); setInterval(updateCounter, 1000);

  // Hearts
  const canvas = document.getElementById('heartCanvas');
  const ctx = canvas.getContext('2d');
  let width,height,dpr;
  function resize(){ dpr=Math.min(window.devicePixelRatio||1,2); width=innerWidth; height=innerHeight; canvas.width=width*dpr; canvas.height=height*dpr; canvas.style.width=width+'px'; canvas.style.height=height+'px'; ctx.setTransform(dpr,0,0,dpr,0,0);} window.addEventListener('resize',resize); resize();
  const hearts=[]; function createHeart(x,y,scale=1,vy=-1.2){ hearts.push({x,y,scale,alpha:1,vy:vy*(0.6+Math.random()*0.8),vx:(Math.random()-0.5)*0.6,rotation:Math.random()*Math.PI,vr:(Math.random()-0.5)*0.05}); }
  function drawHeart(x,y,s,rot,a){ ctx.save(); ctx.translate(x,y); ctx.rotate(rot); ctx.globalAlpha=a; ctx.fillStyle='#ff4d6d'; ctx.beginPath(); ctx.moveTo(0,-0.3*s); ctx.bezierCurveTo(0,-0.8*s,-0.8*s,-0.8*s,-0.8*s,-0.2*s); ctx.bezierCurveTo(-0.8*s,0.3*s,-0.2*s,0.5*s,0,0.8*s); ctx.bezierCurveTo(0.2*s,0.5*s,0.8*s,0.3*s,0.8*s,-0.2*s); ctx.bezierCurveTo(0.8*s,-0.8*s,0,-0.8*s,0,-0.3*s); ctx.closePath(); ctx.fill(); ctx.restore(); }
  function tick(){ ctx.clearRect(0,0,width,height); for (let i=hearts.length-1;i>=0;i--){ const h=hearts[i]; h.x+=h.vx; h.y+=h.vy; h.rotation+=h.vr; h.alpha-=0.006; if (h.alpha<=0||h.y<-40){ hearts.splice(i,1); continue; } drawHeart(h.x,h.y,26*h.scale,h.rotation,Math.max(0,h.alpha)); } requestAnimationFrame(tick);} tick(); setInterval(function(){ createHeart(Math.random()*width,height+20,0.6+Math.random()*0.8,-0.6-Math.random()*0.8); },600);
  const btn=document.getElementById('playFireworks'); if(btn){ btn.addEventListener('click',function(){ for(let i=0;i<28;i++){ setTimeout(function(){ createHeart(width/2+(Math.random()-0.5)*80,height/2+(Math.random()-0.5)*40,0.8+Math.random()*0.8,-1.4-Math.random());}, i*30); } }); }

  // Render gallery from inline ALBUM_ITEMS
  const gridEl = document.getElementById('galleryGrid');
  const progressWrap = document.getElementById('galleryProgressWrap');
  const progressBar = document.getElementById('galleryProgress');
  const progressText = document.getElementById('galleryProgressText');
  const items = (window.ALBUM_ITEMS && window.ALBUM_ITEMS.length) ? window.ALBUM_ITEMS : [];
  if (items.length){
    gridEl.innerHTML='';
    let loaded=0; const total=items.length;
    function showProgress(){ if(!progressWrap) return; progressWrap.style.display='block'; const pct = Math.round(loaded/total*100); progressBar.style.width=pct+'%'; if(progressText) progressText.textContent=loaded+'/'+total+' ('+pct+'%)'; if(loaded>=total){ setTimeout(function(){ progressWrap.style.display='none'; },600); } }
    showProgress();
    items.forEach(function(entry){
      const cell=document.createElement('div'); cell.className='photo';
      cell.dataset.src=entry.src; if(entry.text){ cell.dataset.text=entry.text; }
      gridEl.appendChild(cell);
    });
    const observer=('IntersectionObserver' in window)? new IntersectionObserver(function(entries){ entries.forEach(function(ent){ if(ent.isIntersecting){ const el=ent.target; const s=el.dataset.src; if(s){ const img=new Image(); img.onload=function(){ el.style.backgroundImage='url("'+s+'")'; loaded++; showProgress(); }; img.onerror=function(){ loaded++; showProgress(); }; img.src=s; observer.unobserve(el); } } }); }, {rootMargin:'100px'}): null;
    Array.from(gridEl.querySelectorAll('.photo')).forEach(function(el){ if(observer){ observer.observe(el);} else { const s=el.dataset.src; if(!s) return; const img=new Image(); img.onload=function(){ el.style.backgroundImage='url("'+s+'")'; }; img.src=s; } });
  }

  // Lightbox
  (function(){
    var grid = document.getElementById('galleryGrid');
    var box = document.getElementById('lightbox');
    var img = document.getElementById('lb-img');
    var btnClose = document.querySelector('.lb-close');
    var btnPrev = document.querySelector('.lb-prev');
    var btnNext = document.querySelector('.lb-next');
    var btnPlay = document.querySelector('.lb-play');
    var idxEl = document.getElementById('lb-index');
    var totalEl = document.getElementById('lb-total');
    var textEl = document.getElementById('lb-text');
    var timer=null, current=0, sources=[]; var captions=[];

    function collect(){ var list=Array.from(grid.querySelectorAll('.photo')); sources=list.map(function(el){ return el.dataset.src||''; }); captions=list.map(function(el){ return el.dataset.text||''; }); if(totalEl) totalEl.textContent=String(sources.length); }
    function openAt(i){ if(!sources.length) return; current=(i+sources.length)%sources.length; img.src=sources[current]; if(idxEl) idxEl.textContent=String(current+1); if(textEl) textEl.textContent=captions[current]||''; box.classList.add('active'); box.setAttribute('aria-hidden','false'); }
    function close(){ box.classList.remove('active'); box.setAttribute('aria-hidden','true'); if(timer){ clearInterval(timer); timer=null; } }
    function next(s){ openAt(current+(s||1)); } function prev(){ openAt(current-1); }
    function togglePlay(){ if(timer){ clearInterval(timer); timer=null; btnPlay.textContent='▶'; } else { btnPlay.textContent='❚❚'; timer=setInterval(function(){ next(1); }, 2500); } }

    grid.addEventListener('click', function(e){ var item=e.target.closest('.photo'); if(!item) return; collect(); var items=Array.from(grid.querySelectorAll('.photo')); var i=items.indexOf(item); openAt(i<0?0:i); });
    btnClose.addEventListener('click', close); btnNext.addEventListener('click', function(){ next(1); }); btnPrev.addEventListener('click', function(){ prev(); }); btnPlay.addEventListener('click', togglePlay);
    var sx=0, sy=0, moved=false; box.addEventListener('touchstart', function(e){ if(!box.classList.contains('active')) return; var t=e.touches[0]; sx=t.clientX; sy=t.clientY; moved=false; }, {passive:true}); box.addEventListener('touchmove', function(){ moved=true; }, {passive:true}); box.addEventListener('touchend', function(e){ if(!moved) return; var t=e.changedTouches[0]; var dx=t.clientX-sx; var dy=t.clientY-sy; if(Math.abs(dx)>Math.abs(dy)&&Math.abs(dx)>30){ if(dx<0){ next(1);} else { prev(); } } });
    document.addEventListener('keydown', function(e){ if(!box.classList.contains('active')) return; if(e.key==='Escape') close(); if(e.key==='ArrowRight') next(1); if(e.key==='ArrowLeft') prev(); });
    box.addEventListener('click', function(e){ if(e.target===box) close(); });
  })();

  // Cover + BGM
  (function(){
    var cover = document.getElementById('cover');
    var enter = document.getElementById('enterBtn');
    var audio = document.getElementById('bgm');
    var musicBtn = document.getElementById('musicToggle');
    function setMusicBtn(){ if(!musicBtn || !audio) return; musicBtn.textContent = audio.paused ? '♪' : '❚❚'; }
    if (enter) {
      enter.addEventListener('click', function(){
        if (cover) { cover.style.opacity = '0'; setTimeout(function(){ cover.style.display = 'none'; }, 350); }
        if (audio && audio.src) { audio.play().catch(function(){}); }
        setMusicBtn();
      });
    }
    if (musicBtn && audio) {
      musicBtn.addEventListener('click', function(){
        if (audio.paused) { audio.play().catch(function(){}); } else { audio.pause(); }
        setMusicBtn();
      });
      setMusicBtn();
    }
  })();
})();
"""


def main() -> None:
    project_root = Path(__file__).resolve().parents[1]
    assets_dir = project_root / "assets"
    images_dir = assets_dir / "images"

    base_css = read_text(assets_dir / "style.css")
    extra_css = """
#cover{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:linear-gradient(180deg,rgba(255,143,177,.25),rgba(255,77,109,.25)),#fff;z-index:60;transition:opacity .35s ease}
.cover-content{text-align:center;padding:24px 20px;background:rgba(255,255,255,.6);backdrop-filter:blur(6px);border:1px solid rgba(255,77,109,.15);border-radius:16px}
.cover-content h1{margin:0 0 8px}
.cover-content p{margin:0 0 16px;color:#a05a6a}
.music-btn{position:fixed;right:14px;bottom:14px;border-radius:999px;padding:10px 14px;background:rgba(255,255,255,.85);color:#ff4d6d;border:1px solid rgba(255,77,109,.3);z-index:55}
@media(min-width:560px){.music-btn{right:20px;bottom:20px}}
"""
    css = base_css + "\n" + extra_css
    # 复用现有样式，p1~p6 的占位选择器不会影响
    js = make_inline_js()
    items = build_album_items(images_dir)

    # 可选音乐内嵌（若 assets 目录存在音频文件）
    audio_src = ""
    candidates: list[Path] = []
    for ext in AUDIO_MIME_BY_EXT.keys():
        p = assets_dir / f"music{ext}"
        candidates.append(p)
    if not any(p.exists() for p in candidates):
        for p in assets_dir.iterdir():
            if p.is_file() and p.suffix.lower() in AUDIO_MIME_BY_EXT:
                candidates = [p]
                break
    for p in candidates:
        if p.exists():
            mime = AUDIO_MIME_BY_EXT.get(p.suffix.lower(), "audio/mpeg")
            audio_src = f"data:{mime};base64,{base64.b64encode(p.read_bytes()).decode('ascii')}"
            break

    html = (HTML_TEMPLATE
            .replace("{css}", css)
            .replace("{js}", js)
            .replace("{items_json}", json.dumps(items, ensure_ascii=False, separators=(",", ":")))
            .replace("{audio_src}", audio_src))
    out_file = project_root / "single_album.html"
    out_file.write_text(html, encoding="utf-8")
    print(f"已生成 {out_file.name}，可直接在手机打开，无需服务器或电脑在线。共 {len(items)} 张图片内嵌。")


if __name__ == "__main__":
    main()


