(function () {
  const START_DATE = new Date('2018-08-19T00:00:00+08:00');

  const daysEl = document.getElementById('days');
  const hoursEl = document.getElementById('hours');
  const minutesEl = document.getElementById('minutes');
  const secondsEl = document.getElementById('seconds');

  function pad(n) { return String(n).padStart(2, '0'); }

  function updateCounter() {
    const now = new Date();
    const diffMs = now - START_DATE;
    const totalSeconds = Math.floor(diffMs / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    if (daysEl) daysEl.textContent = days;
    if (hoursEl) hoursEl.textContent = pad(hours);
    if (minutesEl) minutesEl.textContent = pad(minutes);
    if (secondsEl) secondsEl.textContent = pad(seconds);
  }

  updateCounter();
  setInterval(updateCounter, 1000);

  // Canvas hearts
  const canvas = document.getElementById('heartCanvas');
  const ctx = canvas.getContext('2d');
  let width, height, dpr;

  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  window.addEventListener('resize', resize);
  resize();

  const hearts = [];

  function createHeart(x, y, scale = 1, vy = -1.2) {
    hearts.push({
      x,
      y,
      scale,
      alpha: 1,
      vy: vy * (0.6 + Math.random() * 0.8),
      vx: (Math.random() - 0.5) * 0.6,
      rotation: Math.random() * Math.PI,
      vr: (Math.random() - 0.5) * 0.05
    });
  }

  function drawHeart(x, y, size, rotation, alpha) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rotation);
    ctx.globalAlpha = alpha;
    ctx.fillStyle = '#ff4d6d';
    ctx.beginPath();
    const s = size;
    ctx.moveTo(0, -0.3 * s);
    ctx.bezierCurveTo(0, -0.8 * s, -0.8 * s, -0.8 * s, -0.8 * s, -0.2 * s);
    ctx.bezierCurveTo(-0.8 * s, 0.3 * s, -0.2 * s, 0.5 * s, 0, 0.8 * s);
    ctx.bezierCurveTo(0.2 * s, 0.5 * s, 0.8 * s, 0.3 * s, 0.8 * s, -0.2 * s);
    ctx.bezierCurveTo(0.8 * s, -0.8 * s, 0, -0.8 * s, 0, -0.3 * s);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function tick() {
    ctx.clearRect(0, 0, width, height);
    for (let i = hearts.length - 1; i >= 0; i--) {
      const h = hearts[i];
      h.x += h.vx;
      h.y += h.vy;
      h.rotation += h.vr;
      h.alpha -= 0.006;
      if (h.alpha <= 0 || h.y < -40) {
        hearts.splice(i, 1);
        continue;
      }
      drawHeart(h.x, h.y, 26 * h.scale, h.rotation, Math.max(0, h.alpha));
    }
    requestAnimationFrame(tick);
  }

  tick();

  // Auto gentle hearts
  setInterval(function () {
    createHeart(Math.random() * width, height + 20, 0.6 + Math.random() * 0.8, -0.6 - Math.random() * 0.8);
  }, 600);

  // Button burst
  const btn = document.getElementById('playFireworks');
  if (btn) {
    btn.addEventListener('click', function () {
      for (let i = 0; i < 28; i++) {
        setTimeout(function () {
          createHeart(width / 2 + (Math.random() - 0.5) * 80, height / 2 + (Math.random() - 0.5) * 40, 0.8 + Math.random() * 0.8, -1.4 - Math.random());
        }, i * 30);
      }
    });
  }

  // Load all images under assets/images, with progress and captions support
  (function loadGallery() {
    const gridEl = document.getElementById('galleryGrid') || document.querySelector('#gallery .grid');
    const progressWrap = document.getElementById('galleryProgressWrap');
    const progressBar = document.getElementById('galleryProgress');
    const progressText = document.getElementById('galleryProgressText');
    if (!gridEl) return;

    function showProgress(done, total) {
      if (!progressWrap || !progressBar) return;
      progressWrap.style.display = 'block';
      const pct = total > 0 ? Math.round((done / total) * 100) : 0;
      progressBar.style.width = pct + '%';
      if (progressText) progressText.textContent = done + '/' + total + ' (' + pct + '%)';
      if (done >= total) {
        setTimeout(function () { progressWrap.style.display = 'none'; }, 600);
      }
    }

    function render(items) {
      const files = Array.isArray(items) ? items : [];
      if (files.length === 0) return;
      gridEl.innerHTML = '';
      let loaded = 0;
      showProgress(0, files.length);
      files.forEach(function (entry) {
        const src = typeof entry === 'string' ? entry : (entry && entry.src) ? entry.src : '';
        const text = (entry && entry.text) ? String(entry.text) : '';
        if (!src) return;
        const cell = document.createElement('div');
        cell.className = 'photo';
        cell.dataset.src = encodeURI(src);
        if (text) cell.dataset.text = text;
        gridEl.appendChild(cell);
      });

      // lazyload
      const observer = ('IntersectionObserver' in window) ? new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            const el = entry.target;
            const s = el.dataset.src;
            if (s) {
              const img = new Image();
              img.onload = function () {
                el.style.backgroundImage = 'url("' + s + '")';
                loaded += 1; showProgress(loaded, files.length);
              };
              img.onerror = function () {
                loaded += 1; showProgress(loaded, files.length);
              };
              img.src = s;
              observer.unobserve(el);
            }
          }
        });
      }, { rootMargin: '100px' }) : null;

      Array.from(gridEl.querySelectorAll('.photo')).forEach(function (el) {
        if (observer) {
          observer.observe(el);
        } else {
          const s = el.dataset.src; if (!s) return;
          const img = new Image();
          img.onload = function () { el.style.backgroundImage = 'url("' + s + '")'; };
          img.src = s;
        }
      });
    }

    function tryJsonList() {
      return fetch('assets/images/list.json', { cache: 'no-store' })
        .then(function (res) { if (!res.ok) throw new Error('no json'); return res.json(); })
        .then(function (arr) {
          // 支持两种格式：["assets/images/1.jpg", ...] 或 [{src:"...", text:"..."}, ...]
          const files = Array.isArray(arr) ? arr : [];
          render(files);
          return true;
        });
    }

    function tryDirectoryParse() {
      return fetch('assets/images/')
        .then(function (res) { return res.text(); })
        .then(function (html) {
          const parser = new DOMParser();
          const doc = parser.parseFromString(html, 'text/html');
          const anchors = Array.from(doc.querySelectorAll('a'));
          const exts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp'];
          const files = [];
          anchors.forEach(function (a) {
            const href = (a.getAttribute('href') || '').trim();
            const lower = href.toLowerCase();
            if (!href || lower.startsWith('?') || lower.endsWith('/')) return;
            if (!exts.some(function (e) { return lower.endsWith(e); })) return;
            if (href.startsWith('http') || href.startsWith('/')) {
              files.push(href);
            } else {
              files.push('assets/images/' + href);
            }
          });
          const uniqueFiles = Array.from(new Set(files)).sort();
          render(uniqueFiles);
          return true;
        });
    }

    tryJsonList().catch(tryDirectoryParse).catch(function () { /* ignore */ });
  })();

  // Lightbox gallery
  (function lightbox() {
    var grid = document.getElementById('galleryGrid') || document.querySelector('#gallery .grid');
    var box = document.getElementById('lightbox');
    var img = document.getElementById('lb-img');
    var btnClose = document.querySelector('.lb-close');
    var btnPrev = document.querySelector('.lb-prev');
    var btnNext = document.querySelector('.lb-next');
    var btnPlay = document.querySelector('.lb-play');
    var idxEl = document.getElementById('lb-index');
    var totalEl = document.getElementById('lb-total');
    var timer = null;
    var current = 0;
    var sources = [];

    function collectSources() {
      sources = Array.from(grid.querySelectorAll('.photo'))
        .map(function (el) {
          var bg = el.style.backgroundImage || window.getComputedStyle(el).backgroundImage;
          return bg.replace(/^url\(["']?/, '').replace(/["']?\)$/, '');
        })
        .filter(Boolean);
      if (totalEl) totalEl.textContent = sources.length;
    }

    function openAt(i) {
      if (sources.length === 0) return;
      current = (i + sources.length) % sources.length;
      img.src = sources[current];
      if (idxEl) idxEl.textContent = String(current + 1);
      box.classList.add('active');
      box.setAttribute('aria-hidden', 'false');
    }

    function close() {
      box.classList.remove('active');
      box.setAttribute('aria-hidden', 'true');
      if (timer) { clearInterval(timer); timer = null; }
    }

    function next(step) { openAt(current + (step || 1)); }
    function prev() { openAt(current - 1); }

    function togglePlay() {
      if (timer) {
        clearInterval(timer); timer = null; btnPlay.textContent = '▶';
      } else {
        btnPlay.textContent = '❚❚';
        timer = setInterval(function () { next(1); }, 2500);
      }
    }

    // Click to open
    grid.addEventListener('click', function (e) {
      var target = e.target;
      var item = target.closest('.photo');
      if (!item) return;
      collectSources();
      var items = Array.from(grid.querySelectorAll('.photo'));
      var i = items.indexOf(item);
      openAt(i < 0 ? 0 : i);
    });

    // Buttons
    btnClose.addEventListener('click', close);
    btnNext.addEventListener('click', function(){ next(1); });
    btnPrev.addEventListener('click', function(){ prev(); });
    btnPlay.addEventListener('click', togglePlay);

    // Swipe support
    var touchStartX = 0; var touchStartY = 0; var moved = false;
    box.addEventListener('touchstart', function (e) {
      if (!box.classList.contains('active')) return;
      var t = e.touches[0];
      touchStartX = t.clientX; touchStartY = t.clientY; moved = false;
    }, { passive: true });
    box.addEventListener('touchmove', function (e) {
      moved = true;
    }, { passive: true });
    box.addEventListener('touchend', function (e) {
      if (!moved) return;
      var t = e.changedTouches[0];
      var dx = t.clientX - touchStartX; var dy = t.clientY - touchStartY;
      if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 30) {
        if (dx < 0) { next(1); } else { prev(); }
      }
    });

    // Keyboard
    document.addEventListener('keydown', function (e) {
      if (!box.classList.contains('active')) return;
      if (e.key === 'Escape') close();
      if (e.key === 'ArrowRight') next(1);
      if (e.key === 'ArrowLeft') prev();
    });

    // Click mask to close
    box.addEventListener('click', function (e) {
      if (e.target === box) close();
    });
  })();
})();


